package org.dex.istw

import android.content.Context
import android.os.AsyncTask
import android.util.Log
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException


interface AreaInfoListener {
    fun onGet(result: DATA?, isTW: Boolean)
}


data class DATA(
    @SerializedName("country") var country: String = "",//Taiwan
    @SerializedName("countryCode") var countryCode: String = "",//TW
    @SerializedName("city") var city: String = "",//Taipei
    @SerializedName("region") var region: String = "",//TPE
    @SerializedName("regionName") var regionName: String = "",//Taipei City
    @SerializedName("lat") var lat: String = "",
    @SerializedName("lon") var lon: String = "",
    @SerializedName("query") var ip: String = "",//ip
    @SerializedName("status") var status: String = ""//success
)

class IPTask(context: Context, listener: AreaInfoListener, log: Boolean) : AsyncTask<Void, Void, DATA>() {
    val context: Context = context
    val log: Boolean = log//show log
    val listener: AreaInfoListener = listener


    override fun onPostExecute(result: DATA?) {
        var isTW: Boolean = result?.country?.toLowerCase().equals("taiwan")
        listener.onGet(result, isTW)
    }

    override fun doInBackground(vararg params: Void?): DATA? {

        val url = context.getString(R.string.get_ip_url)
        if (log) Log.i(IPTask::class.java.simpleName, "request url: $url")
        val request: Request = Request.Builder().url(url).build()
        val client = OkHttpClient()
        try {
            val response: Response = client.newCall(request).execute()
            val get = response.body!!.string()
            if (log) Log.i(IPTask::class.java.simpleName, "dexter get ip area response: $get")
            return Gson().fromJson(get, DATA::class.java!!)
        } catch (e: IOException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }
}


fun areaInfo(context: Context, listener: AreaInfoListener, showLog: Boolean) {

    IPTask(context, listener, showLog).execute()

}