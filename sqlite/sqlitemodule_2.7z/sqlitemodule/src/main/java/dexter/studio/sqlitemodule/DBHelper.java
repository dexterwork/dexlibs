package dexter.studio.sqlitemodule;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/**
 * Created by Dexter on 2017/4/15.
 */

public abstract class DBHelper extends SQLiteOpenHelper {

    protected HashMap<String, BasicTable> tableMap;
    Context context;

    public DBHelper(Context context, String name, int version) {
        super(context, Environment.getExternalStorageDirectory()
                + File.separator + context.getPackageName()
                + File.separator + name, null, version);
        this.context = context;
        this.tableMap = getTableMap();
    }

    private HashMap<String, BasicTable> getTableMap() {
        HashMap<String, BasicTable> map = new HashMap<>();
        List<BasicTable> list = getTableList();
        for (BasicTable bt : list) {
            map.put(bt.tableName, bt);
        }
        return map;
    }

    /**
     * 在table 新增欄位, 應該要在 onUpgrade 中呼叫
     * @param db
     * @param tableName
     * @param columnName
     * @param fieldType
     */
    protected void addColumn(SQLiteDatabase db, String tableName, String columnName, FieldTypeEnum fieldType) {
        String cmd = "ALTER TABLE " + tableName + " ADD COLUMN " + columnName + " " + fieldType.name();
        db.execSQL(cmd);
    }

    protected abstract List<BasicTable> getTableList();

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.v("DBHelper", "dexter onCreate");
        Iterator<BasicTable> iterator = tableMap.values().iterator();
        while (iterator.hasNext()) {
            BasicTable bt = iterator.next();
            Log.v("create table", "create table:" + bt.tableName);
            db.execSQL(bt.getCreateTableCmd());
        }
    }


    private static SQLiteDatabase database;

    public SQLiteDatabase getDatabase() {
        if (database == null || !database.isOpen()) {
            database = getWritableDatabase();
        }

        return database;
    }

    public void close() {
        if (database != null && database.isOpen()) database.close();
    }

    public long insert(String tableName, ContentValues contentValues) {
        return getDatabase().insert(tableName, null, contentValues);
    }

    public void insert(String tableName, List<ContentValues> cvList) {
        for (ContentValues cv : cvList) {
            long id = insert(tableName, cv);
            Log.v("insert", "insert id=" + id + "/table=" + tableName);
        }
    }

    public boolean update(String tableName, ContentValues contentValues, String where) {
        return getDatabase().update(tableName, contentValues, where, null) > 0;
    }

    public boolean delete(String tableName, String where) {
        return getDatabase().delete(tableName, where, null) > 0;
    }

    public List<ContentValues> getAll(String tableName) {
        Cursor cursor = getDatabase().query(tableName, null, null, null, null, null, null, null);
        cursor.moveToFirst();

        BasicTable table = tableMap.get(tableName);
        List<FieldTypeBundle> fieldList = table.fieldList;
        List<ContentValues> list = new ArrayList<>();
//        String msg = "";
        if (cursor.getCount() == 0) return list;
        do {
            ContentValues cv = new ContentValues();
            for (FieldTypeBundle fb : fieldList) {
                String field = fb.fieldName;
                int cIndex = cursor.getColumnIndex(field);

                switch (cursor.getType(cIndex)) {
                    case Cursor.FIELD_TYPE_STRING:
                        cv.put(field, cursor.getString(cIndex));
                        break;
                    case Cursor.FIELD_TYPE_INTEGER:
                        cv.put(field, cursor.getInt(cIndex));
                        break;
                    case Cursor.FIELD_TYPE_NULL:

                        break;
                }
//                msg += field + "=" + value + "\n";
//                Log.i("get all", field + "=" + value);

            }
            list.add(cv);
        } while (cursor.moveToNext());

//        cursor.close();
//        AlertDialog.Builder builder = new AlertDialog.Builder(context);
//        builder.setMessage(msg);
//        builder.show();
        return list;
    }


}
