package dexter.studio.sqlitemodule;

import java.util.Iterator;
import java.util.List;

/**
 * Created by Dexter on 2017/4/15.
 */

public abstract class BasicTable {

    public  String tableName;
    public List<FieldTypeBundle> fieldList;

    public  final String KEY_ID = "_id";

    public BasicTable() {
        this.tableName = initTableName();
        this.fieldList = initFieldList();
    }

    protected abstract String initTableName();
    protected abstract List<FieldTypeBundle>  initFieldList();

    /**
     * 取得建立資料表的指令
     *
     * @return
     */
    public String getCreateTableCmd() {

        String cmd = "CREATE TABLE " + tableName + " (" + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, ";

        Iterator<FieldTypeBundle> iterator = fieldList.iterator();
        while (iterator.hasNext()) {
            FieldTypeBundle b = iterator.next();
            cmd += getFieldCmd(b);
            if (iterator.hasNext()) cmd += ", ";
        }
        cmd += ")";
        return cmd;
    }

    private String getFieldCmd(FieldTypeBundle bundle) {
        String cmd = bundle.fieldName + " " + bundle.fieldTypeEnum.name();
        if (!bundle.canNull) cmd += " NOT NULL";
        return cmd;
    }

//    public List<String> getFieldsName() {
//        List<String> list = new ArrayList<>();
//        Field[] fields = getClass().getDeclaredFields();
//        for (Field f : fields) {
//            list.add(f.getName());
//        }
//        return list;
//    }

}
