package dexter.studio.sqlitemodule.sample;

import java.util.ArrayList;
import java.util.List;

import dexter.studio.sqlitemodule.BasicTable;
import dexter.studio.sqlitemodule.FieldTypeBundle;
import dexter.studio.sqlitemodule.FieldTypeEnum;

/**
 * Created by Dexter on 2017/4/15.
 */

public class Table0 extends BasicTable {

//    public String name;
//    public String birth;
//    public String member_id;
//    public String pay;

    @Override
    protected String initTableName() {
        return "member";
    }

    @Override
    protected List<FieldTypeBundle> initFieldList() {
        List<FieldTypeBundle> list = new ArrayList<>();

        list.add(new FieldTypeBundle("name", FieldTypeEnum.TEXT));
        list.add(new FieldTypeBundle("birth", FieldTypeEnum.TEXT));
        list.add(new FieldTypeBundle("member_id", FieldTypeEnum.TEXT));
        list.add(new FieldTypeBundle("pay", FieldTypeEnum.TEXT));
        return list;
    }


}
