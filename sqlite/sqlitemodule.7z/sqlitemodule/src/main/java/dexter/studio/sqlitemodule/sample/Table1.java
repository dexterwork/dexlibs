package dexter.studio.sqlitemodule.sample;

import java.util.ArrayList;
import java.util.List;

import dexter.studio.sqlitemodule.BasicTable;
import dexter.studio.sqlitemodule.FieldTypeBundle;
import dexter.studio.sqlitemodule.FieldTypeEnum;

/**
 * Created by Dexter on 2017/4/15.
 */

public class Table1 extends BasicTable {
    @Override
    protected String initTableName() {
        return "pay";
    }

    @Override
    protected List<FieldTypeBundle> initFieldList() {
        List<FieldTypeBundle> list=new ArrayList<>();

       list.add(new FieldTypeBundle("pay_name", FieldTypeEnum.TEXT));
       list.add(new FieldTypeBundle("pay", FieldTypeEnum.TEXT));
        return list;
    }
}
