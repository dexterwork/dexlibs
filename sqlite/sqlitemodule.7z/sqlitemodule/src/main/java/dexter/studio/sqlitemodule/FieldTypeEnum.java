package dexter.studio.sqlitemodule;

/**
 * Created by Dexter on 2017/4/15.
 */

public enum FieldTypeEnum {

    TEXT, INTEGER, BOOL

}
