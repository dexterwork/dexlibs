package dexter.studio.sqlitemodule.sample;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import dexter.studio.sqlitemodule.BasicTable;
import dexter.studio.sqlitemodule.DBHelper;

/**
 * Created by Dexter on 2017/4/15.
 */

public class DbSample {
    public MyDb mDB;

    public DbSample(Context context) {
        mDB = new MyDb(context);
//        insert();
//        delete();
//        update();
        mDB.getAll(new Table0().tableName);
    }

    public void insert(){
        List<ContentValues> list = new ArrayList<>();
//        ContentValues cv0 = new ContentValues();
//        cv0.put("name", "dex");
//        cv0.put("birth", "1999-01-01");
//        cv0.put("member_id", 564);
//        list.add(cv0);

        ContentValues cv1 = new ContentValues();
        cv1.put("name", "emily");
        cv1.put("birth", "2011-03-03");
        cv1.put("member_id", 988);
        cv1.put("pay", true);
        list.add(cv1);


        mDB.insert(new Table0().tableName, list);

    }

    public void update(){
        ContentValues cv=new ContentValues();
        cv.put("pay",false);
        String where="name='dex'";
        mDB.update(new Table0().tableName,cv, where );
    }

    public void delete(){
        String where="_id=4";
        mDB.delete(new Table0().tableName,where);
    }

    public void close() {
        mDB.close();
    }

    public class MyDb extends DBHelper {
        public MyDb(Context context) {
            super(context, "db_sample.db", 1);//DB名稱與版本號在這裡寫死
        }


        @Override
        protected List<BasicTable> getTableList() {
            List<BasicTable> tableList = new ArrayList<>();
            tableList.add(new Table0());
            tableList.add(new Table1());
            return tableList;
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        }
    }
}
