package dexter.studio.sqlitemodule;

/**
 * use for create table.
 * Created by Dexter on 2017/4/15.
 */

public class FieldTypeBundle {

    public String fieldName;

    public FieldTypeEnum fieldTypeEnum;

    public boolean canNull;//是否允許為null, 預設為允許


    public FieldTypeBundle(String fieldName, FieldTypeEnum fieldTypeEnum) {
        this(fieldName, fieldTypeEnum, true);
    }

    public FieldTypeBundle(String fieldName, FieldTypeEnum fieldTypeEnum, boolean canNull) {
        this.fieldName = fieldName;
        this.fieldTypeEnum = fieldTypeEnum;
        this.canNull = canNull;
    }


}
