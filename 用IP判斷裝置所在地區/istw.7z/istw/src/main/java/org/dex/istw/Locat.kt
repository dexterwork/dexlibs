package org.dex.istw

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.telephony.TelephonyManager
import android.text.TextUtils
import android.util.Log


/*
台灣本島範圍(包含綠島/蘭嶼)
緯度最北:25.30, 最南:12.88
經度最西:120.02, 最東:122.02

澎湖
緯度最北:23.80, 最南:23.18
經度最西:119.31, 最東:122.02(包含台灣最東)

馬祖
緯度最北:26.285, 最南:26.137
經度最西:119.908, 最東:120.017

莒光鄉
緯度最北:25.982, 最南:25.935
經度最西:119.924, 最東:119.996

東引
緯度最北:26.386, 最南:26.353
經度最西:120.467, 最東:120.515

亮島
緯度最北:26.349, 最南:26.334
經度最西:120.216, 最東:120.231

金門
緯度最北:24.529, 最南:24.385
經度最西:118.211, 最東:118.506


 */



// 0:未成功檢查, 1:為台灣, 2:非台灣
fun inTW(context: Context?): Int {
    if (context == null) return 0
    try {
        val telManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        var country = telManager.networkCountryIso
        Log.w("Locat", "country: $country")
        if (TextUtils.isEmpty(country)) return 0
        var tw = country.toLowerCase().contains("tw")
        return if (tw) 1 else 2
    } catch (e: NullPointerException) {
    } catch (e: Exception) {
    }
    return 0
}

fun inArea(latitude: Double, longitude: Double): String {
    var list = ArrayList<AreaData>()
    list.add(AreaData("台灣本島", 122.02, 120.02, 12.88, 25.30))
    list.add(AreaData("澎湖", 122.02, 119.31, 23.18, 23.80))
    list.add(AreaData("馬祖", 120.017, 119.908, 26.137, 26.285))
    list.add(AreaData("金門", 118.506, 118.211, 24.385, 24.529))
    list.add(AreaData("莒光鄉", 119.996, 118.211, 24.385, 24.529))
    list.add(AreaData("東引", 120.515, 120.467, 26.353, 26.386))
    list.add(AreaData("亮島", 120.231, 118.211, 26.334, 26.349))



    for (area: AreaData in list) {
        if (longitude <= area.east && longitude >= area.west &&
            latitude <= area.north && latitude >= area.south
        ) {
            Log.i("Locat", "latitude: $latitude, longitude: $longitude in ${area.name}")
            return area.name
        }
    }

    return ""
}

data class AreaData(val name: String, val east: Double, val west: Double, val south: Double, val north: Double)

var locationManager: LocationManager? = null

var gps_enabled: Boolean = false
var network_enabled: Boolean = false
var passive_enabled: Boolean = false

fun locationEnable(context: Context): Boolean {

    if (locationManager == null) locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    if (locationManager == null) return false


    //是否可用
    try {
        gps_enabled = locationManager!!.isProviderEnabled(LocationManager.GPS_PROVIDER)
    } catch (e: Exception) {
        e.printStackTrace()
    }

    try {
        network_enabled = locationManager!!.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    } catch (e: Exception) {
        e.printStackTrace()
    }

    try {
        passive_enabled = locationManager!!.isProviderEnabled(LocationManager.PASSIVE_PROVIDER)
    } catch (e: Exception) {
        e.printStackTrace()
    }

    return gps_enabled || network_enabled || passive_enabled
}


fun requestLocationUpdate(act: Activity, requestCode: Int, listener: OnLocListener) {
    onLocListener = listener
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        if (act.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            act.requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), requestCode)
            return
        }
        if (act.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            act.requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), requestCode)
            return
        }
    }


    if (gps_enabled) {
        locationManager?.requestLocationUpdates(
            LocationManager.GPS_PROVIDER,
            0L,
            0f,
            LocatListener(LocationManager.GPS_PROVIDER)
        )
    }
    if (network_enabled) {
        locationManager?.requestLocationUpdates(
            LocationManager.NETWORK_PROVIDER,
            0L,
            0f,
            LocatListener(LocationManager.NETWORK_PROVIDER)
        )
    }
    if (passive_enabled) {
        locationManager?.requestLocationUpdates(
            LocationManager.PASSIVE_PROVIDER,
            0L,
            0f,
            LocatListener(LocationManager.PASSIVE_PROVIDER)
        )
    }
}

var onLocListener: OnLocListener? = null

interface OnLocListener {
    fun onLocationChanged(providerName: String, location: Location?)
}

class LocatListener(providerName: String) : LocationListener {

    override fun onLocationChanged(location: Location?) {
        onLocListener?.onLocationChanged(providerName, location)
    }

    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
        Log.w("LocatListener", "onStatusChanged $provider $status")
    }

    override fun onProviderEnabled(provider: String?) {
        Log.w("LocatListener", "onProviderEnabled $provider")
    }

    override fun onProviderDisabled(provider: String?) {
        Log.w("LocatListener", "onProviderDisabled $provider")
    }

    val providerName: String = providerName
}




