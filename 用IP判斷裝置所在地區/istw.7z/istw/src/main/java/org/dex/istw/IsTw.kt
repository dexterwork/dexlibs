package org.dex.istw

import android.content.Context
import android.util.Log

class IsTw(context: Context, listener: IsTwListener?) {

    private val context: Context = context
    private val listener: IsTwListener? = listener
    private var checkType: CheckType? = null

    private fun exec(showLog: Boolean, checkType: CheckType) {
        this.checkType = checkType
        this.checkType = CheckType.IP
        //TODO 目前只有 IP
        when (checkType) {
            CheckType.IP -> {
                this.checkType = CheckType.DONE
                checkIP(showLog)
            }
            CheckType.LOCAL -> {
                this.checkType = CheckType.DONE
                checkLocal(showLog)
            }
            CheckType.IP_LOCAL -> {
                this.checkType = CheckType.LOCAL
                checkIP(showLog)
            }
            CheckType.LOCAL_IP -> {
                this.checkType = CheckType.IP
                checkLocal(showLog)
            }
            CheckType.DONE -> TODO()
        }

    }

    private fun checkLocal(showLog: Boolean) {
//Locat
    }

    fun exec(showLog: Boolean) {
        exec(showLog, CheckType.IP)
    }

    private fun checkIP(showLog: Boolean) {
        areaInfo(context, object : AreaInfoListener {
            override fun onGet(result: DATA?, isTW: Boolean) {
                Log.i(IsTw::class.java.simpleName, "response is TW? $isTW")
                listener?.onResponse(result, isTW)
//                if (isTW) listener?.onResponse(result, isTW)
//                else {
//
//                }
            }
        }, showLog)
    }

}

interface IsTwListener {
    fun onResponse(result: DATA?, isTW: Boolean)
}

enum class CheckType {
    IP, //check ip only
    LOCAL, //check local only
    IP_LOCAL, //check ip first then local
    LOCAL_IP, //check local first then ip
    DONE//check done
}
